// P3.1 - greeting with the user's first name
function showGreeting() {
    const user = getCurrentUser();
    const greetingEl = document.getElementById('greeting');
    // This is important cause it's check's is or not page loaded
    if (!user || !greetingEl) return;

    const firstName = user.fullName.split(' ')[0];
    greetingEl.textContent = `Welcome back, ${firstName}!`;
}

// P3.1 - clock that updates every second
function startLiveClock() {
    const clockEl = document.getElementById('live-clock');
    const dateEl = document.getElementById('live-date');
    // This is important cause it's check's is or not page loaded
    if (!clockEl || !dateEl) return;

    function tick() {
        clockEl.textContent = new Date().toLocaleTimeString();
        dateEl.textContent = new Date().toLocaleDateString();
    }

    tick();
    setInterval(tick, 1000);
}

// bring 'crm_clients' clients or return empty array
function loadClientsSimple() {
    return JSON.parse(localStorage.getItem('crm_clients')) || [];
}

function renderStats(clients) {
    const totalEl = document.getElementById('stat-total-clients');
    if (!totalEl) return;

    totalEl.textContent = clients.length;

    const activeDeals = clients.filter(c => c.status !== 'Won' && c.status !== 'Lost');
    document.getElementById('stat-active-deals').textContent = activeDeals.length;

    const wonRevenue = clients.filter(c => c.status === 'Won').reduce((sum, c) => sum + c.dealValue, 0);
    document.getElementById('stat-won-revenue').textContent = '$' + wonRevenue.toLocaleString();

    const oneWeekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const newThisWeek = clients.filter(c => new Date(c.createdAt).getTime() >= oneWeekAgo);
    document.getElementById('stat-new-week').textContent = newThisWeek.length;
}


document.addEventListener('DOMContentLoaded', () => {
    showGreeting();
    startLiveClock();

    renderStats(loadClientsSimple());
});